package flights.testcases;

import org.testng.annotations.Test;

import flights.library.Loginpage;
import flights.library.isFlightTicketBooked;
import utils.AppUtils;

public class flightticket extends AppUtils
{
	@Test
	public void FlightTicketBooking() throws InterruptedException
	{
		Loginpage lp = new Loginpage();
		lp.login("sureshbabu.qedge@gmail.com", "demo");
		
		isFlightTicketBooked flight = new isFlightTicketBooked();
		flight.ticketbooking("15/May/2023", "Hyderabad", "Kolkatha", "Air India", "Hanuman", "3");
		lp.logout();
	}

}
