package flights.testcases;

import org.testng.annotations.Test;

import flights.library.Loginpage;
import utils.AppUtils;

public class Userlogin extends AppUtils  {
	@Test
    public void login()
	{
		Loginpage lp = new Loginpage();
		lp.login("sureshbabu.qedge@gmail.com", "demo");
		lp.logout();

        		
	}
}

