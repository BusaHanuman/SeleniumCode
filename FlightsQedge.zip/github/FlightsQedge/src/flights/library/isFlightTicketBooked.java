package flights.library;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.AppUtils;

public class isFlightTicketBooked extends AppUtils
{
	public void ticketbooking(String doj, String cityfrom, String cityto,String airline,String name, String noofpassengers) throws InterruptedException 
	{
	
		String[] cal = doj.split("/");
		String dt = cal[0];
		String mon = cal[1];
		String yr = cal[2];
		driver.findElement(By.id("search-date")).click();
		String calyear = driver.findElement(By.className("ui-datepicker-year")).getText();
		while(!calyear.equals(yr))
		{
			driver.findElement(By.linkText("Next")).click();
			calyear = driver.findElement(By.className("ui-datepicker-year")).getText();
			
		}
		String calmonth = driver.findElement(By.className("ui-datepicker-month")).getText();
		while(!calmonth.equals(mon))
		{
			driver.findElement(By.linkText("Next")).click();
			calmonth = driver.findElement(By.className("ui-datepicker-month")).getText();
		   
		}
		WebElement calendar = driver.findElement(By.className("ui-datepicker-calendar"));
		List<WebElement> rows = calendar.findElements(By.tagName("tr"));
		for(int i=1;i<rows.size();i++)
		{
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
			for(int j=0;j<cols.size();j++)
			{
				String date = cols.get(j).getText();
				if(date.equals(dt))
				{
					cols.get(j).click();
					break;
				}
				
			}
		}
		Thread.sleep(2000);
		Select city1 = new Select(driver.findElement(By.xpath("/html/body/section[2]/div/div[2]/div/div[2]/div[1]/div/div/div[2]/select")));
		 city1.selectByVisibleText(cityfrom);
		 Select city2 = new Select(driver.findElement(By.xpath("/html/body/section[2]/div/div[2]/div/div[2]/div[1]/div/div/div[3]/select")));
		 city2.selectByVisibleText(cityto);
		 driver.findElement(By.xpath("/html/body/section[2]/div/div[2]/div/div[2]/div[1]/div/div/div[4]/button")).click();
		 Thread.sleep(5000);
		/*WebDriverWait wait = new WebDriverWait(driver, 20);
		 wait.until(ExpectedConditions.elementToBeClickable(By.className("flights_table")));*/
		 driver.switchTo().defaultContent().findElement(By.className("flights_table"));
		 WebElement flightstable = driver.findElement(By.className("flights_table"));
		    List<WebElement> rows1,cols;	
		     rows1 = flightstable.findElements(By.tagName("tr"));
		     for(int i=1;i<rows1.size();i++)
		     {
		    	 cols = rows1.get(i).findElements(By.tagName("td"));
		    	 if(cols.get(0).getText().equalsIgnoreCase(airline))
		    	 {
		    		cols.get(8).findElement(By.xpath("//*[@data-id='1']")).click();
		    	 }
		     }
		     driver.findElement(By.id("name")).sendKeys(name);
		    WebElement checkbox = driver.findElement(By.xpath("//*[@value='Business']"));
		    checkbox.click();
		    WebElement tkt =driver.findElement(By.id("tickets"));
		    tkt.clear();
		    Thread.sleep(5000);
		    driver.findElement(By.id("tickets")).sendKeys(noofpassengers);;
		    driver.findElement(By.xpath("/html/body/section[2]/div/div[2]/div/div[2]/div[1]/div/div/form/div/div[4]/div/button")).click();
	}

	

	
		
	}


