package flights.library;

import org.openqa.selenium.By;

import utils.AppUtils;

public class Loginpage extends AppUtils
{
	public boolean login(String uid, String pwd)
	{
		driver.findElement(By.name("email")).sendKeys(uid);
		driver.findElement(By.name("password")).sendKeys(pwd);
		driver.findElement(By.xpath("//*[@type='submit']")).click();
		if(driver.findElement(By.className("a_logo")).isDisplayed())
		{
			return true;
		}else
		{
			return false;
		}
	}
	public void logout()
	{
		driver.findElement(By.xpath("/html/body/header/nav/div/div[3]/ul/li[2]/div/a/i")).click();
		driver.findElement(By.linkText("Logout")).click();
	}
}

